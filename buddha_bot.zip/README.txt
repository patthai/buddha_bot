A Pen created at CodePen.io. You can find this one at https://codepen.io/dudleystorey/pen/knqyK.

 Technique explained in [the related blog post](http://thenewcode.com/777/Create-Fullscreen-HTML5-Page-Background-Video)